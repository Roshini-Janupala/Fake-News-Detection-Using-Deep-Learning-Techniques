from flask import Flask, render_template, request, jsonify
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.text import one_hot
from tensorflow.keras.preprocessing.sequence import pad_sequences
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
import pandas as pd

app = Flask(__name__)

# Load the trained model
model = load_model('your_model.h5')

# Load NLTK resources
nltk.download('stopwords')
ps = PorterStemmer()
stop_words = set(stopwords.words('english'))

# Load the dataset
dataset = pd.read_csv('DATASET_2.csv', encoding='latin1')

# Define the vocabulary size and sentence length
voc_size = 5000
sent_length = 20

# Define a function to preprocess text
def preprocess_text(text):
    review = re.sub('[^a-zA-Z]', ' ', text)
    review = review.lower()
    review = review.split()
    review = [ps.stem(word) for word in review if not word in stop_words]
    review = ' '.join(review)
    return review

# Prediction endpoint
@app.route('/predict', methods=['POST'])
def predict():
    text = request.form['text']
    processed_text = preprocess_text(text)
    onehot_repr = [one_hot(processed_text, voc_size)]
    padded_text = pad_sequences(onehot_repr, padding='pre', maxlen=sent_length)
    prediction = model.predict(padded_text)
    prediction_label = "True" if prediction[0][0] >= 0.5 else "False"
    return jsonify({'prediction': prediction_label})

# Route to serve HTML file
@app.route('/')
def home():
    return render_template('index.html')

# Route for random sample
@app.route('/random-sample', methods=['GET'])
def random_sample():
    sample = dataset.sample(n=1)['text'].values[0]
    return jsonify({'sample': sample})

if __name__ == '__main__':
    app.run(debug=True)
